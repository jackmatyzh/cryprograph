How to install this plugin?

-In your WordPress Dashboard navigate Plugins
-Click Install Plugins and then click Add New
-Click the Upload Plugin button
-Upload the plugin ZIP file that you've downloaded and click OK
-Click Install Plugin to start the installation
-When installation is complete, click Activate
-This last step activates the plugin and after it plugin is ready

How to display a convertor on a page?
-Just use a shortcode [crypto] on any page you want to display a plugin to.
-Everything else is going to be automatic.
-Plugin is allready connected with https://coinmarketcap.com/ via API. And gets updates every 5 min.

